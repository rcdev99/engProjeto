package negocio;

import dominio.Entidade_Dominio;
import dominio.Funcionario;

public class ValidadorDadosPessoais implements IStrategy {

	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		StringBuilder sb = new StringBuilder();
        
		if(entidadedominio instanceof Funcionario) {
			Funcionario funcionario = (Funcionario)entidadedominio;
			
			if(funcionario.getNome() == null || funcionario.getNome().trim().equals("")) {
				sb.append("\nCAMPO 'NOME' N�O PREENCHIDO!");
			}
			
			if(funcionario.getRg() == null || funcionario.getRg().trim().equals("")) {
				sb.append("\nRG N�O INFORMADO!");
			} else {
				ValidadorRG valRG = new ValidadorRG();
				String msg = valRG.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getCpf() == null || funcionario.getCpf().trim().equals("")) {
				sb.append("\nCPF N�O INFORMADO!");
			} else {
				ValidadorCPF valCPF = new ValidadorCPF();
				String msg = valCPF.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getLogin() == null || funcionario.getLogin().trim().equals("")) {
				sb.append("\nCAMPO 'LOGIN' N�O PREENCHIDO");
			} else {
				ValidadorDuplicidadeLogin valLogin = new ValidadorDuplicidadeLogin();
				String msg = valLogin.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getSenha() == null || funcionario.getSenha().trim().equals("")) {
				sb.append("\nCAMPO 'SENHA' N�O PREENCHIDO");
			} else {
				ValidadorSenha valSenha= new ValidadorSenha();
				String msg = valSenha.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getE_mail() == null || funcionario.getE_mail().trim().equals("")) {
				sb.append("\nCAMPO 'E-MAIL' N�O PREENCHIDO!");
			}
			
			if(funcionario.getCargo() == null || funcionario.getCargo().trim().equals("")) {
				sb.append("\nCAMPO 'CARGO' N�O PREENCHIDO!");
			}
			
			
		} else {
			return "\nIMPOSS�VEL VALIDAR, POIS N�O � UM FUNCIONARIO!";
		}
		
		if(sb.length() > 0) {
			return sb.toString();
		}
		
		return null;
	}

	
	
}
