package negocio;

import dominio.Entidade_Dominio;
import dominio.Funcionario;

public class ValidadorCPF implements IStrategy {

	int i;
	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		if(entidadedominio instanceof Funcionario){
			Funcionario funcionario = (Funcionario)entidadedominio;
			
			if(funcionario.getCpf().length() != 11){
				return "\nPREENCHA CORRETAMENTE O CAMPO 'CPF'";
			} else {
				try { 
					 i = Integer.valueOf(funcionario.getCpf());
				} catch (NumberFormatException nfe) {
					return "\nCPF N�O PODE SER VALIDADO, POIS CPF N�O NUM�RICO!";
				}
			}
			
		}else{
			return "\nCPF N�O PODE SER VALIDADO, POIS ENTIDADE N�O � UM FUNCIONARIO!";
		}
		return null;
	}

}
