package negocio;

import dominio.Entidade_Dominio;
import dominio.Funcionario;

public class ValidadorRG implements IStrategy {

	int i;
	
	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		if(entidadedominio instanceof Funcionario){
			Funcionario funcionario = (Funcionario)entidadedominio;
			
			if(funcionario.getRg().length() != 9){
				return "\nPREENCHA CORRETAMENTE O CAMPO 'RG'";
			} else {
				try { 
					i = Integer.valueOf(funcionario.getCpf());
				} catch (NumberFormatException nfe) {
					return "\nRG N�O PODE SER VALIDADO, POIS N�O � NUM�RICO!";
				}
			}
			
		}else{
			return "\nRG N�O PODE SER VALIDADO, POIS ENTIDADE N�O � UM FUNCIONARIO!";
		}
		return null;
	}

}
