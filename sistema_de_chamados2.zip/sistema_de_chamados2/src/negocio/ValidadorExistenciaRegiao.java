package negocio;

import java.sql.SQLException;
import java.util.List;

import dao.IDAO;
import dao.RegionalDAO;
import dominio.Entidade_Dominio;
import dominio.Regional;

public class ValidadorExistenciaRegiao implements IStrategy {

	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		
		Regional regiao = (Regional)entidadedominio;
		IDAO dao = new RegionalDAO();
		boolean controle = true;
		
		try {
			List<Entidade_Dominio> regioes = dao.consultar(regiao);
			
			if(regioes != null) {
				if(regioes.size() == 1) {
					Regional regiaoToCompare = (Regional) regioes.get(0);
					
					if(regiao.getRegiao() != regiaoToCompare.getRegiao()) {
						controle = false;
					}
					
					if(regiao.getCod() != regiaoToCompare.getCod()) {
						controle = false;
					}
					
					if(controle) {
						return "\n REGIONAL V�LIDO";
					} else {
						return "\n REGIONAL INFORMADO N�O EXISTE";
					}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return null;
}

}
