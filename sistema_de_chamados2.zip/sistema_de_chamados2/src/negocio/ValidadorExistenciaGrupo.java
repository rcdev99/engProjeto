
package negocio;

import java.sql.SQLException;
import java.util.List;

import dao.GrupoDAO;
import dao.IDAO;
import dominio.Entidade_Dominio;
import dominio.Grupo;


public class ValidadorExistenciaGrupo implements IStrategy {
	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		
			Grupo grupo = (Grupo)entidadedominio;
			IDAO dao = new GrupoDAO();
			boolean controle = true;
			
			try {
				List<Entidade_Dominio> grupos = dao.consultar(grupo);
				
				if(grupos != null) {
					if(grupos.size() == 1) {
						Grupo grupoToCompare = (Grupo) grupos.get(0);
						
						if(grupo.getNome() != grupoToCompare.getNome()) {
							controle = false;
						}
						
						if(grupo.getCod() != grupoToCompare.getCod()) {
							controle = false;
						}
						
						if(controle) {
							return "\n GRUPO V�LIDO";
						} else {
							return "\n GRUPO INFORMADO N�O EXISTE";
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return null;
	}

}
