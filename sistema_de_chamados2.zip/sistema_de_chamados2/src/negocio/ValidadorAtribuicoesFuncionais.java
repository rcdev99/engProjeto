package negocio;

import dominio.Entidade_Dominio;
import dominio.Funcionario;

public class ValidadorAtribuicoesFuncionais implements IStrategy{

	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		
		StringBuilder sb = new StringBuilder();
		
		if(entidadedominio instanceof Funcionario) {
			Funcionario funcionario = (Funcionario)entidadedominio;
			
			if(funcionario.getSetor() == null || funcionario.getSetor().getSetor().trim().equals("")) {
				sb.append("\nCAMPO 'SETOR' N�O PREENCHIDO!");
			} else {
				ValidadorExistenciaSetor valSetorExiste = new ValidadorExistenciaSetor();
				String msg = valSetorExiste.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getResponsavel() == null || funcionario.getResponsavel().getNome().trim().equals("")) {
				sb.append("\nCAMPO 'RESPONSAVEL' N�O PREENCHIDO!");
			} else {
				ValidadorExistenciaResponsavel valResponsavelExiste = new ValidadorExistenciaResponsavel();
				String msg = valResponsavelExiste.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getRegiao() == null || funcionario.getRegiao().getRegiao().trim().equals("")) {
				sb.append("\nCAMPO 'REGI�O' N�O PREENCHIDO!");
			} else {
				ValidadorExistenciaRegiao valRegiaoExiste = new ValidadorExistenciaRegiao();
				String msg = valRegiaoExiste.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getGrupo() == null || funcionario.getGrupo().getNome().trim().equals("")) {
				sb.append("\nCAMPO 'GRUPO' N�O PREENCHIDO!");
			} else {
				ValidadorExistenciaGrupo valGrupoExiste = new ValidadorExistenciaGrupo();
				String msg = valGrupoExiste.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
			if(funcionario.getPfl() == null || funcionario.getPfl().getTipoPerfil().trim().equals("")) {
				sb.append("\nCAMPO 'PERFIL' N�O PREENCHIDO!");
			} else {
				ValidadorExistenciaPerfil valPerfilExiste = new ValidadorExistenciaPerfil();
				String msg = valPerfilExiste.processar(funcionario);
				if(msg != null) {
					sb.append(msg);
				}
			}
			
		} else {
			return "\nIMPOSS�VEL VALIDAR, POIS N�O � UM FUNCIONARIO!";
		}
		
		if(sb.length() > 0) {
			return sb.toString();
		}
		
		return null;
	}
	
}
