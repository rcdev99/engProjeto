package negocio;

import java.sql.SQLException;
import java.util.List;

import dao.IDAO;
import dao.SetorDAO;
import dominio.Entidade_Dominio;
import dominio.Setor;

public class ValidadorExistenciaSetor implements IStrategy {

		@Override
		public String processar(Entidade_Dominio entidadedominio) {
			
			Setor setor = (Setor)entidadedominio;
			IDAO dao = new SetorDAO();
			boolean controle = true;
			
			try {
				List<Entidade_Dominio> setores = dao.consultar(setor);
				
				if(setores != null) {
					if(setores.size() == 1) {
						Setor setorToCompare = (Setor) setores.get(0);
						
						if(setor.getSetor() != setorToCompare.getSetor()) {
							controle = false;
						}
						
						if(setor.getCod() != setorToCompare.getCod()) {
							controle = false;
						}
						
						if(controle) {
							return "\n SETOR V�LIDO";
						} else {
							return "\n SETOR INFORMADO N�O EXISTE";
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return null;
	}
}	
	