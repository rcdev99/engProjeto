package negocio;

import java.sql.SQLException;
import java.util.List;

import dao.FuncionarioDAO;
import dao.IDAO;
import dominio.Entidade_Dominio;
import dominio.Funcionario;

public class ValidadorExistenciaResponsavel implements IStrategy {

	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		Funcionario responsavel = (Funcionario)entidadedominio;
		IDAO dao = new FuncionarioDAO();
		boolean controle = true;
		
		try {
			List<Entidade_Dominio> funcionarios = dao.consultar(responsavel);
			
			if(responsavel != null) {
				if(funcionarios.size() == 1) {
					Funcionario funcionarioToCompare = (Funcionario) funcionarios.get(0);
					
					if(responsavel.getNome() != funcionarioToCompare.getNome()) {
						controle = false;
					}
					
					if(responsavel.getMatricula() != funcionarioToCompare.getMatricula()) {
						controle = false;
					}
					
					if(controle) {
						return "\n RESPONS�VEL V�LIDO";
					} else {
						return "\n RESPONS�VEL INFORMADO N�O EXISTE";
					}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return null;
}

}