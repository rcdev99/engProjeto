package negocio;

import dominio.Entidade_Dominio;

public class ValidadorDuplicidadeLogin implements IStrategy{

	@Override
	public String processar(Entidade_Dominio entidadedominio) {
		// TODO Auto-generated method stub
		return null;
	}

}
