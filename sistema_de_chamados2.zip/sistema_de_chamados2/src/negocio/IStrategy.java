package negocio;

import dominio.*;

public interface IStrategy {

	public String processar(Entidade_Dominio entidadedominio);
	
}
