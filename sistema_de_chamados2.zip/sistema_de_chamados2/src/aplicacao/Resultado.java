package aplicacao;

import java.util.List;

import dominio.Entidade_Dominio;

public class Resultado {

	private String msg;
	private List<Entidade_Dominio> entidades;
	
	public List<Entidade_Dominio> getEntidades() {
		return entidades;
	}
	
	public void setEntidades(List<Entidade_Dominio> entidades) {
		this.entidades = entidades;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	} 
	
}
