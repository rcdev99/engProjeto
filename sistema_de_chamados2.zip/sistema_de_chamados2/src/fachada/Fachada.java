package fachada;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import negocio.*;
import aplicacao.Resultado;
import dao.FuncionarioDAO;
import dao.IDAO;
import dominio.Entidade_Dominio;
import dominio.Funcionario;

public class Fachada implements IFachada {
	
	private Map<String, Map<String, List<IStrategy>>> rns;
	private Map<String, IDAO> daos;
	private Resultado resultado;
	
	public Fachada() {
		// Mapa de DAOS
		daos = new HashMap<String, IDAO>();
		// Mapa de Regras de Neg�cio
		rns = new HashMap<String, Map<String, List<IStrategy>>>();
		
		//Instancia dos DAOS a serem utilizados
		FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		
		// Adicionando MAP de acordo com o nome da classe
		daos.put(Funcionario.class.getName(), funcionarioDAO);
		
		
		//Inst�nciando as regras de neg�cio
		ValidadorDadosPessoais valDadosPessoais = new ValidadorDadosPessoais();
		ValidadorDuplicidadeLogin valLogin = new ValidadorDuplicidadeLogin();
		ValidadorSenha valSenha = new ValidadorSenha();
		ValidadorAtribuicoesFuncionais valAtribuicoesFuncionais = new  ValidadorAtribuicoesFuncionais(); 
		ValidadorExistenciaResponsavel valExistResp = new ValidadorExistenciaResponsavel();
		ValidadorExistenciaRegiao valExistRegiao = new ValidadorExistenciaRegiao();
		ValidadorExistenciaGrupo valExistGrupo = new ValidadorExistenciaGrupo();
		ValidadorExistenciaPerfil valExistPerfil = new ValidadorExistenciaPerfil();
		
		
		//Cria��o da lista de RNS para a opera��o salvar
		List<IStrategy> rnsSalvarFuncionario = new ArrayList<IStrategy>();
		
		//Adic�o das regras a serem utilizadas na opera��o salvar (funcionario)
		rnsSalvarFuncionario.add(valDadosPessoais);
		rnsSalvarFuncionario.add(valLogin);
		rnsSalvarFuncionario.add(valSenha);
		rnsSalvarFuncionario.add(valAtribuicoesFuncionais);
		rnsSalvarFuncionario.add(valExistResp);
		rnsSalvarFuncionario.add(valExistRegiao);
		rnsSalvarFuncionario.add(valExistGrupo);
		rnsSalvarFuncionario.add(valExistPerfil);
		
		
		/* 
		 * Cria o mapa que poder� conter todas as listas de regras de neg�cio espec�fica 
		 * por opera��o do cliente
		 */
		Map<String, List<IStrategy>> rnsFuncionario = new HashMap<String, List<IStrategy>>();
		
		/*
		 * Adiciona todas lista de regras no mapa do cliente
		 */
		rnsFuncionario.put("SALVAR", rnsSalvarFuncionario);
		
		rns.put(Funcionario.class.getName(), rnsFuncionario);
		
	}

	@Override
	public Resultado salvar(Entidade_Dominio entidadedominio) {
		
		resultado = new Resultado();
		String nmClasse = entidadedominio.getClass().getName();	
		
		String msg = executarRegras(entidadedominio, "SALVAR");
		
		
		if(msg == null){
			IDAO dao = daos.get(nmClasse);
			try {
				dao.salvar(entidadedominio);
				List<Entidade_Dominio> entidades = new ArrayList<Entidade_Dominio>();
				entidades.add(entidadedominio);
				resultado.setEntidades(entidades);
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("N�o foi poss�vel realizar o registro!");
			}
		}else{
			resultado.setMsg(msg);
		}
		
		return resultado;
	}

	private String executarRegras(Entidade_Dominio entidade, String operacao) {
		
		String nmClasse = entidade.getClass().getName();		
		StringBuilder msg = new StringBuilder();
		
		Map<String, List<IStrategy>> regrasOperacao = rns.get(nmClasse);
		
		if(regrasOperacao != null){
			List<IStrategy> regras = regrasOperacao.get(operacao);
			
			if(regras != null){
				for(IStrategy s: regras){			
					String m = s.processar(entidade);			
					
					if(m != null){
						msg.append(m);
						msg.append("\n");
					}			
				}	
			}			
		}
		
		if(msg.length()>0)
			return msg.toString();
		else
			return null;
	}

	@Override
	public Resultado alterar(Entidade_Dominio entidadedominio) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Resultado consultar(Entidade_Dominio entidadedominio) {
		
		resultado = new Resultado();
		String nmClasse = entidadedominio.getClass().getName();	
		
		String msg = executarRegras(entidadedominio, "CONSULTAR");
		
		
		if(msg == null){
			IDAO dao = daos.get(nmClasse);
			try {
				resultado.setEntidades(dao.consultar(entidadedominio));
			} catch (SQLException e) {
				e.printStackTrace();
				resultado.setMsg("N�o foi poss�vel realizar o registro!");
			}
		}else{
			resultado.setMsg(msg);
		}
		
		return resultado;
	}

	@Override
	public Resultado excluir(Entidade_Dominio entidadedominio) {
		// TODO Auto-generated method stub
		return null;
	}

}
