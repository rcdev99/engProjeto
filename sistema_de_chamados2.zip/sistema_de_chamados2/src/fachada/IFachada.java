package fachada;

import dominio.*;
import aplicacao.*;

public interface IFachada {
	
	public Resultado salvar(Entidade_Dominio entidadedominio);
	public Resultado alterar(Entidade_Dominio entidadedominio);
	public Resultado consultar(Entidade_Dominio entidadedominio);
	public Resultado excluir(Entidade_Dominio entidadedominio);
	
	
}
