package fachada;

import controle.Fachada;
import controle.IFachada;
import dominio.*;;


public class TesteFachadaSalvarRegional {
	
	public static void main(String[] args) {
		
		
		Regional regional = new Regional (12,"Roraima");
		IFachada fachada = new Fachada();
		
		System.out.println(fachada.salvar(regional));
		
	}


}
