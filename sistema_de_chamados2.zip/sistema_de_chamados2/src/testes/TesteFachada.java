package testes;
import controle.Fachada;
import controle.IFachada;
import dominio.*;;

public class TesteFachada {
	
public static void main(String[] args) {
		
		//Funcionario func = new Funcionario(1, true, "ricardo06.rodrigues@blablabla.com", "Ricard�o", "O filho do chefe");
		//Regional reg = new Regional("Sul");
		Regional reg1 = new Regional( "ro");
		//Setor setor = new Setor(1, "Cria��o de bugs");
		//Grupo grupo = new Grupo(1, "Intensifica��o de bugs");
		
		
		
		IFachada fachada = new Fachada();
		
		//System.out.println(fachada.salvar(reg));
		System.out.println(fachada.consultar(reg1));
		/*
		System.out.println(fachada.salvar(setor));
		System.out.println(fachada.salvar(grupo));
		System.out.println(fachada.salvar(func));
		*/
	}

}
