package dominio;

public class Anexo extends Entidade_Dominio {
	
	String tipoArquivo;
	
}
