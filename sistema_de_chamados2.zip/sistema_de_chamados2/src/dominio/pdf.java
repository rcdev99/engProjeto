package dominio;

public class pdf extends Anexo{

}
