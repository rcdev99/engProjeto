package dominio;

public class Inativacao extends Entidade_Dominio {

	String motivo;
}
