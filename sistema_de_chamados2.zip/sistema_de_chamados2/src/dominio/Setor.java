package dominio;

public class Setor extends Entidade_Dominio{
	
	private int cod;
	private String setor;
	
	//Construtor
	public Setor(int cod, String setor){
		
		this.cod = cod;
		this.setor = setor;
	}
	
	public Setor() {
		// TODO Auto-generated constructor stub
	}

	//Getters e Setters
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getSetor() {
		return setor;
	}
	public void setSetor(String setor) {
		this.setor = setor;
	}
	
	
}
