package dominio;

import java.util.ArrayList;

public class Grupo extends Entidade_Dominio {

	private int cod;
	private String nome;
	ArrayList<Funcionario> funcionarios;
	
	//Construtor
	public Grupo(int cod, String nome) {
		
		this.cod = cod;
		this.nome = nome;
		
	}
	
	public Grupo() {
		// TODO Auto-generated constructor stub
	}

	//Getters e Setters
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
