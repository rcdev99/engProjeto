package dominio;

public class png extends Anexo{

}
