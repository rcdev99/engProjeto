package dominio;

public class logTransacao extends Entidade_Dominio {

}
