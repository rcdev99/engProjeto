package dominio;

public class TriagemInicial extends Administrativo{
	
	public boolean atribuiGrupo(Chamado ch, Grupo grupo) {
		
		return true;
	}

}
