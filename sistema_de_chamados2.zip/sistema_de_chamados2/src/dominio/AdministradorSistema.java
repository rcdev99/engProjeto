package dominio;

public class AdministradorSistema extends Administrativo{

	public void cadastrarCategoria() {
		
	}
	public boolean inativarCategoria() {
		
		return true;
	}
	public void cadastrarSubcategoria(Categoria categoria) {
		
	}
	public boolean inativarSubcategoria(Subcategoria subcategoria) {
		
		return true;
	}
	public boolean cadastrarGrupo() {
		
		return true;
	}
	public boolean inativarGrupo() {
		
		return true;
	}
	public boolean aprovarCancelamento(Chamado ch) {
		
		return true;
	}
	public void cadastrarConhecimento() {
		
	}
	public void inativarConhecimento() {
		
	}
	public void alterarConhecimento() {
		
	}
	public boolean editarGrupo(Grupo gp) {
		
		return true;
	}
	


}//class
