package dominio;

public class jpg extends Anexo {

}
