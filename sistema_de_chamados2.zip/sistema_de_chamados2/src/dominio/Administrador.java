package dominio;

public class Administrador extends Administrativo {
	
	public boolean alterarAtendente(Chamado ch) {
		
		return true;
	}
	public boolean alterarGrupo(Chamado ch, Grupo grupo) {
		
		return true;
	}
	public void cadastrarGrupo() {
		
	}
	public void inativarGrupo(Grupo grupo) {
		
	}
	public void atribuirPerfil(Funcionario func){
		
	}
	public void visualizarSolicCanc() {
		
	}
	public boolean aprovarCancelamento(Chamado ch) {
		
		return true;
	}
	public boolean aprovarConhecimento(Conhecimento conhecimento) {
		
		return true;
	}
	public boolean inativarConhecimento(Conhecimento conhecimento) {
		
		return true;
	}
	public boolean alterarConhecimento(Conhecimento conhecimento) {
		
		return true;
	}
	public boolean editarGrupo(Grupo grupo) {
		
		return true;
	}

}
