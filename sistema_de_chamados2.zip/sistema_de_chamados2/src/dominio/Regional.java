package dominio;

public class Regional extends Entidade_Dominio{

	private int cod;
	private String regiao;
	private boolean status = false ;
	
	public Regional() {
		status = true;
	}
	public Regional(int cod) {
		this.cod = cod;
	}
	public Regional(int cod, String regiao) {
		
		this.cod = cod;
		this.regiao = regiao;
		status = true;
		
	}
	public Regional(String string) {
		this.regiao = string;
		status = true;
	}
	public String toString() {
		
		return "Id: " + getCod() + "| Regi�o: " + getRegiao();
		
	}

	//Getters e Setters
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getRegiao() {
		return regiao;
	}
	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
}
