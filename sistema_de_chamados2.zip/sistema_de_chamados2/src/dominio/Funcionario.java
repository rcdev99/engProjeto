package dominio;

import java.sql.Date;

public class Funcionario extends Usuario{
	
	private int matricula ;
	private boolean status;
	private String e_mail;
	private Funcionario responsavel;
	private String cargo;
	private Date dt_contratacao;
	private Setor setor;
	private Regional regiao;
	private Grupo grupo;
	Inativacao inativacao;
	private Perfil pf;
	
	public Funcionario() {
		
		this.status = true;
		
	}
	 
	
	//Getters e Setters
	public int getMatricula() {
		return matricula;
	}
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getE_mail() {
		return e_mail;
	}
	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}
	public Funcionario getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(Funcionario responsavel) {
		this.responsavel = responsavel;
	}
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public Date getDt_contratacao() {
		return dt_contratacao;
	}
	public void setDt_contratacao(Date dt_contratacao) {
		this.dt_contratacao = dt_contratacao;
	}
	public Setor getSetor() {
		return setor;
	}
	public void setSetor(Setor setor) {
		this.setor = setor;
	}
	public Regional getRegiao() {
			return regiao;
	}
	public void setRegiao(Regional regiao) {
			this.regiao = regiao;
	}
	public int getIdRegiao() {
		
		return regiao.getCod();
	}
	public void setIdRegiao(int reg) {
		
		regiao.setCod(reg);
	}
	public int getIdSetor() {
		
		return setor.getCod();
	}
	public void setIdSetor(int str) {
		
		setor.setCod(str);
	}
	public int getIdGrupo() {
		
		return grupo.getCod();
	}
	public void setIdGrupo(int gpo) {
		
		grupo.setCod(gpo);
	}

	public Grupo getGrupo() {
		return grupo;
	}

	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}
	
	
	public int getIdResponsavel() {
		
		return responsavel.getMatricula();
	}
	public void setIdResponsavel(int res) {
		
		responsavel.setMatricula(res);
	}


	public Perfil getPfl() {
		return pf;
	}


	public void setPfl(Perfil pf) {
		this.pf = pf;
	}
	

}
