package dominio;

import java.util.ArrayList;

public class Triagem extends Entidade_Dominio {

	ArrayList<Chamado> chamados = new ArrayList<Chamado>() ;
	
	public boolean adicionarChamado (Chamado ch) {
		
	return true;	
	}
}
