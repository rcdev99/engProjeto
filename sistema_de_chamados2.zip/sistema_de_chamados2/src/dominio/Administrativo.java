package dominio;

public abstract class Administrativo extends Perfil {

	public void redefinirCategoria(Chamado ch) {	

	}
	public void redefinirSubcategoria(Subcategoria sub) {	

	}
}
