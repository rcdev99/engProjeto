package dominio;

public class jpeg extends Anexo {

}
