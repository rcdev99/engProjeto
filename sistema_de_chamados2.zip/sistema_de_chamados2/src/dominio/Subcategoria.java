package dominio;

import java.sql.Date;

public class Subcategoria extends Entidade_Dominio {
	
	Categoria categoria;
	private int cod;
	private String subcategoria;
	private String descricao;
	private boolean status;
	private Date prazoAtendimento;
	
	public Subcategoria(Categoria categoria) {
		boolean statusCat = categoria.getStatus();
		if (statusCat != false) {
			System.out.println("Categoria inativa ! ");
			return; 
		}
		if (categoria.getNome() == null || categoria.getNome() == " " ) {
			System.out.println("Categoria inv�lida ! ");
			return;
		}
		this.categoria = categoria;
	}
	
	public Subcategoria() {
		
	}

	//Getters e Setters
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
		super.setId(cod);
	}
	public String getSubcategoria() {
		return subcategoria;
	}
	public void setSubcategoria(String subcategoria) {
		this.subcategoria = subcategoria;
	}
	public String getDescricao() {
		return descricao;
	}
	public Categoria getCategoria() {
		
		return categoria;
		
	}
	public int getCategoriaId() {
		return categoria.getCodigo();
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public boolean getStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Date getPrazoAtendimento() {
		return prazoAtendimento;
	}
	public void setPrazoAtendimento(Date prazoAtendimento) {
		this.prazoAtendimento = prazoAtendimento;
	}
	public void setCategoria(Categoria categoria) {
		
		this.categoria = categoria;
		
	}
	public void setCategoriaId(int codigo) {
		categoria.setCodigo(codigo);
	}

}
