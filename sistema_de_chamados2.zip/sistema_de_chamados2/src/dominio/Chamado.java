package dominio;

import java.sql.Date;
import java.util.ArrayList;

public class Chamado extends Entidade_Dominio {
	
	private int cod;
	private String nome;
	private boolean status;
	private String descricao;
	private String situacao;
	private Funcionario responsavel;
	private Setor setor;
	private Regional regiao;
	private Date dt_abertura;
	private Date dt_encerramento;
	private Date previsaoEncerramento;
	private Anexo anexo;
	private Categoria categoria;
	private Subcategoria subcategoria;
	private Grupo grupo;
	private Conhecimento conhecimento;
	ArrayList<Conhecimento>conhecimentos = new ArrayList<Conhecimento>(); 
	
	public Chamado() {
		setStatus(true);
	}
	
	//Getters e Setters
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public boolean getStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	public Funcionario getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(Funcionario responsavel) {
		this.responsavel = responsavel;
	}
	public String getSetor() {
		return setor.getSetor();
	}
	public void setSetor(Setor setor) {
		this.setor = setor;
	}
	public Regional getRegiao() {
		return regiao;
	}
	public void setRegiao(Regional regiao) {
		this.regiao = regiao;
	}
	public Date getDt_abertura() {
		return dt_abertura;
	}
	public void setDt_abertura(Date dt_abertura) {
		this.dt_abertura = dt_abertura;
	}
	public void setCategoriaId(Categoria categoria) {
		this.categoria.setCodigo(categoria.getCodigo());
	}
	public Date getDt_encerramento() {
		return dt_encerramento;
	}
	public void setDt_encerramento(Date dt_encerramento) {
		this.dt_encerramento = dt_encerramento;
	}
	public Date getPrevisaoEncerramento() {
		return previsaoEncerramento;
	}
	public void setPrevisaoEncarramento(Date previsaoEncarramento) {
		this.previsaoEncerramento = previsaoEncarramento;
	}
	public Anexo getAnexo() {
		return anexo;
	}
	public void setAnexo(Anexo anexo) {
		this.anexo = anexo;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public int getCategoriaId() {
		return categoria.getCodigo();
	}
	
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public Subcategoria getSubcategoria() {
		return subcategoria;
	}
	public int getSubcategoriaId() {
		return subcategoria.getCod();
	}
	public void setSubcategoriaId(Subcategoria subcategoria) {
		this.subcategoria.setCod(subcategoria.getCategoriaId());
	}
	public Grupo getGrupo() {
		return grupo;
	}
	public int getGrupoId() {
		return grupo.getCod();
	}
	public void setGrupo(Grupo grupo) {
		this.grupo.setCod(grupo.getCod());
	}
	public int getResponsavelId() {
		return responsavel.getMatricula();
	}
	public void setResponsavelId(Funcionario responsavel) {
		this.responsavel.setMatricula(responsavel.getMatricula());
	}
	public int getSetorId() {
		return setor.getCod();
	}
	public void setSetorId(Setor setor) {
		this.setor.setCod(setor.getCod());
		
	}
	public int getRegionalId() {
		return regiao.getCod();
	}
	public void setRegiaoId(Regional regiao) {
		this.regiao.setCod(regiao.getCod());
	}
	public Conhecimento getConhecimento() {
		return conhecimento;
	}
	public void setConhecimento(Conhecimento conhecimento) {
		this.conhecimento = conhecimento;
	}
	public int getConhecimentoId() {
		return conhecimento.getCodigo();
	}
	public void setConhecimentoId(Conhecimento con) {
		conhecimento.setCodigo(con.getCodigo());
	}
	public boolean getStatus2() {
		return true;
	}
}
