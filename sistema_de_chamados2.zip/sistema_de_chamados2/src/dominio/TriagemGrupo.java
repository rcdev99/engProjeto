package dominio;

public class TriagemGrupo extends Administrativo {

	public boolean atribuiResponsavel(Chamado ch, Atendente atdt) {
		
		return true;
	}
	public boolean atribuiGrupo(Chamado ch, Grupo grupo) {
		
		return true;
	}
}
