package dominio;

public class Atendente extends Perfil{
	
	public boolean cadastrarChamado() {
		
		return true;
	}
	public boolean cancelarChamado() {
		
		return true;
	}
	public boolean finalizarChamado(Chamado ch) {
		
		return true;
	}
	public boolean realizarAtendimento (Chamado ch) {
	
		return true; 
	}
	
}
