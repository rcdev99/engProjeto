package command;

import aplicacao.Resultado;
import dominio.Entidade_Dominio;

public class ExcluirCommand extends AbstractCommand{

	@Override
	public Resultado execute(Entidade_Dominio entidadedominio) {
		return fachada.excluir(entidadedominio);
	}

}
