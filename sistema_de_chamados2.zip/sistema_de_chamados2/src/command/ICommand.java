package command;

import aplicacao.Resultado;
import dominio.Entidade_Dominio;

public interface ICommand {

	public Resultado execute(Entidade_Dominio entidadedominio);
	
}
