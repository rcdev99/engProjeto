package command;

import aplicacao.Resultado;
import dominio.Entidade_Dominio;

public class ConsultarCommand extends AbstractCommand {

	@Override
	public Resultado execute(Entidade_Dominio entidadedominio) {
		return fachada.consultar(entidadedominio);
		}

}
