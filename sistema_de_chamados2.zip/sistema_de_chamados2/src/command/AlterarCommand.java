package command;

import aplicacao.Resultado;
import dominio.Entidade_Dominio;

public class AlterarCommand extends AbstractCommand {

	@Override
	public Resultado execute(Entidade_Dominio entidadedominio) {
		return fachada.alterar(entidadedominio);
	}

}
