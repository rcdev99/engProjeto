package command;

import aplicacao.Resultado;
import dominio.Entidade_Dominio;

public class SalvarCommand extends AbstractCommand{
	
	public Resultado execute(Entidade_Dominio entidadedominio) {
		return fachada.salvar(entidadedominio);
	}


}
