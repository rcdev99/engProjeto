package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aplicacao.Resultado;
import command.AlterarCommand;
import command.ConsultarCommand;
import command.ExcluirCommand;
import command.ICommand;
import command.SalvarCommand;
import dominio.Entidade_Dominio;
import vh.FuncionarioViewHelper;
import vh.IViewHelper;

/**
 * Servlet implementation class Servlet
 */
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Map<String, ICommand> commands;
	private static Map<String, IViewHelper> vhs;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
    	/* Utilizando o command para chamar a fachada e indexando cada command 
    	 * pela opera��o garantimos que esta servelt atender� qualquer opera��o */
    	commands = new HashMap<String, ICommand>();
		
		commands.put("SALVAR", new SalvarCommand());
		commands.put("ALTERAR", new AlterarCommand());
		commands.put("CONSULTAR", new ConsultarCommand());
		commands.put("EXCLUIR", new ExcluirCommand());
		
		String contextoApp = "/sistema_de_chamados2";
		
		/* Utilizando o ViewHelper para tratar especifica��es de qualquer tela e indexando 
    	 * cada viewhelper pela url em que esta servlet � chamada no form
    	 * garantimos que esta servelt atender� qualquer entidade */
		vhs = new HashMap<String, IViewHelper>();
		
		/*A chave do mapa � o mapeamento da servlet para cada form que 
    	 * est� configurado no web.xml e sendo utilizada no action do html
    	 */
		vhs.put(contextoApp + "/cadastrar", new FuncionarioViewHelper());
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	protected void doProcessRequest(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		// Obt�m a URI que invocou esta servlet (requisi��o), indicada no action no form
		// (O que foi definido no methdo do form html)
		String uri = request.getRequestURI();
		
		// Obt�m um viewhelper indexado pela uri que invocou esta servlet, 
		// mapeada no hashmap do construtor da servlet
		IViewHelper vh = vhs.get(uri);
		
		// O viewhelper retorna a entidade especifica para a tela que chamou esta servlet
		Entidade_Dominio entidadedominio = vh.getEntidade(request);
			
		// Obt�m a opera��o executada, aqui recebe o valor do atributo "operacao" no formul�rio,
		// que � do tipo hidden, e ser� utilizado para identificar o command no map
		String operacao = request.getParameter("OPERACAO");
		
		
		// Obt�m o command para executar a respectiva opera��o
		ICommand command = commands.get(operacao);
		
		/*
		 * Executa o command que chamar� a fachada para executar a opera��o requisitada
		 * o retorno � uma inst�ncia da classe resultado que pode conter mensagens de erro 
		 * ou entidades de retorno
		 */
		Resultado resultado = command.execute(entidadedominio);
		
		/*
		 * Executa o m�todo setView do view helper espec�fico para definir como dever� ser  
		 * apresentado o resultado para o usu�rio
		 */
		vh.setView(resultado, request, response);
	}}
	
	/*	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operacao = request.getParameter("OPERACAO");
		Resultado resultado = new Resultado();
		String uri = request.getRequestURI();
		IViewHelper vh = vhs.get(uri);
		if(vh != null) {
			if(operacao != null && !operacao.equals("")) {
				Entidade_Dominio entidade = vh.getEntidade(request);
				ICommand cmd = commands.get(operacao);
				resultado = cmd.execute(entidade);
			}
			vh.setView(resultado, request, response);
		}
	}
	

}*/
