package controle;

import java.util.List;

import dominio.Entidade_Dominio;

public interface IFachada {
	public String salvar(Entidade_Dominio entidadeDominio);
	public String alterar(Entidade_Dominio entidadeDominio);
	public String excluir(Entidade_Dominio entidadeDominio);
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadeDominio);
}
