package controle;

public class ControleFuncionario {

}
