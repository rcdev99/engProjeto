package controle;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.GrupoDAO;
import dao.IDAO;
import dao.RegionalDAO;
import dao.SetorDAO;
import dominio.*;

public class Fachada implements IFachada  {
	
	@Override
	public String salvar(Entidade_Dominio entidade) {
		Regional regional= (Regional)entidade;
		IDAO daoRegional = new RegionalDAO();
		try {
			daoRegional.salvar(regional);
			System.out.println("Opera��o concluida");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return "REGIONAL SALVO COM SUCESSO!";
	}
	public String salvarGrupo(Entidade_Dominio entidade) {
		Grupo grupo= (Grupo)entidade;
		IDAO daoGrupo = new GrupoDAO();
		try {
			daoGrupo.salvar(grupo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return "GRUPO SALVO COM SUCESSO!";
	}
	public String salvarSetor(Entidade_Dominio entidade) {
		Setor setor= (Setor)entidade;
		IDAO daoSetor= new SetorDAO();
		try {
			daoSetor.salvar(setor);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return "SETOR SALVO COM SUCESSO!";
	}
	public String salvarFunc(Entidade_Dominio entidade) {
		Funcionario func= (Funcionario)entidade;
		IDAO daoFunc= new SetorDAO();
		try {
			daoFunc.salvar(func);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return "FUNCIONARIO SALVO COM SUCESSO!";
	}
	

	@Override
	public String alterar(Entidade_Dominio entidade) {
		Regional regional= (Regional)entidade;
		IDAO daoRegional = new RegionalDAO();
		try {
			daoRegional.alterar(regional);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return "REGIONAL ALTERADO COM SUCESSO!";
	}

	@Override
	public String excluir(Entidade_Dominio entidade) {
		Regional regional= (Regional)entidade;
		IDAO daoRegional = new RegionalDAO();
		try {
			daoRegional.excluir(regional);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return "REGIONAL EXLCLU�DO COM SUCESSO!";
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidade) {
		Regional regional= (Regional)entidade;
		IDAO daoRegional = new RegionalDAO();
		List<Entidade_Dominio> regioes = new ArrayList<Entidade_Dominio>();
		
		try {
			regioes = daoRegional.consultar(regional);
			for (Entidade_Dominio regiao: regioes) {
				System.out.println(regiao.toString());
			};
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
		}
		
		return regioes;
	}

}
