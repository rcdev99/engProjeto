package vh;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aplicacao.Resultado;
import dominio.*;
import dominio.Entidade_Dominio;
import dominio.Funcionario;
import dominio.Regional;
import dominio.Setor;

public class FuncionarioViewHelper implements IViewHelper {
	
	public Entidade_Dominio getEntidade(HttpServletRequest request) {
		
		Funcionario funcionario = new Funcionario();
		Setor setor = new Setor();
		Funcionario responsavel = new Funcionario();
		Regional regiao = new Regional();
		Grupo grupo = new Grupo();
		Perfil perfil = new Perfil();
		
		
		
		
		String operacao = request.getParameter("OPERACAO");
		if(operacao != null) {
			if(operacao.equals("SALVAR")) {
				String nome = request.getParameter("nome");
				String sobrenome = request.getParameter("sobrenome");
				String rg = request.getParameter("rg");
				String cpf = request.getParameter("cpf");
				String login = request.getParameter("login");
				String e_mail = request.getParameter("e_mail");
				String senha = request.getParameter("senha");
				
				String cargo = request.getParameter("cargo");
				String setorNm = request.getParameter("setor");
				String responsavelNm = request.getParameter("responsavel");
				String regiaoNm = request.getParameter("regiao");
				String grupoNm = request.getParameter("grupo");
				String perfilNm = request.getParameter("perfil");
				
				funcionario.setNome(nome);
				funcionario.setSobrenome(sobrenome);
				funcionario.setRg(rg);
				funcionario.setCpf(cpf);
				funcionario.setLogin(login);
				funcionario.setE_mail(e_mail);
				funcionario.setSenha(senha);
				funcionario.setCargo(cargo);
				
				//inser��o nas classes
				setor.setSetor(setorNm);
				responsavel.setNome(responsavelNm);
				regiao.setRegiao(regiaoNm);
				grupo.setNome(grupoNm);
				perfil.setTipoPerfil(perfilNm);
				
				//insere classes no object funcion�rio
				funcionario.setSetor(setor);
				funcionario.setResponsavel(responsavel);
				funcionario.setGrupo(grupo);
				funcionario.setRegiao(regiao);
				funcionario.setPfl(perfil);
			}
		}
		return funcionario;
	}

	public void setView(Resultado resultado, HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String uri = request.getRequestURI();
		if(uri.equals("/cadastrar")) {
			request.getRequestDispatcher("WEB-INF/jsp/index.html").forward(request, response);
			return;
		}
		
	}
	

}
