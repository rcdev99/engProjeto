package vh;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aplicacao.Resultado;
import dominio.*;

public interface IViewHelper {

public Entidade_Dominio getEntidade(HttpServletRequest request);
	
	public void setView(Resultado resultado, HttpServletRequest request, 
			HttpServletResponse response)throws IOException, ServletException;
	
}
