package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dominio.Categoria;
import dominio.Entidade_Dominio;

public class CategoriaDAO extends AbstractJdbcDAO { 
	
	private static final String name_table = "categoria";
	private static final String id_table = "cat_id";
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public CategoriaDAO() {
		super(name_table, id_table);
	}
	
	public CategoriaDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(Entidade_Dominio entidadedominio) throws SQLException {
		// TODO Auto-generated method stub
	
		if(connection == null) {
			openConnection();
		}
		
		Categoria categoria = (Categoria)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("cat_status, cat_nome, cat_descricao) ");
			sql.append("VALUES (?,?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setBoolean(1, categoria.getStatus());
			pst.setString(2, categoria.getNome());
			pst.setString(3, categoria.getDescricao());
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idCategoria = 0;
			if(rs.next())
				idCategoria = rs.getInt(1);
			categoria.setId(idCategoria);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		
		
	} 

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Categoria categoria = (Categoria)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("cat_ status, cat_nome, cat_descricao");
			sql.append(" = (?,?,?) ");
			sql.append("WHERE "); 
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setBoolean(1, categoria.getStatus());
			pst.setString(2, categoria.getNome());
			pst.setString(3, categoria.getDescricao());
			pst.setInt(4, categoria.getCodigo());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Categoria categoria= (Categoria)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("DELETE FROM ");
			sql.append(name_table);
			sql.append(" WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, categoria.getCodigo());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		Categoria categoria = (Categoria)entidadedominio;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM ");
		sql.append(name_table);
		
		sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
		
		if(categoria.getCodigo()  > 0) {
			sql.append(" AND categoria.cat_id = ");
			sql.append(categoria.getCodigo());
		}
		
		if(categoria.getNome() != null) {
			sql.append(" AND categoria.cat_nome ILIKE '%");
			sql.append(categoria.getNome());
			sql.append("%'");
		}
		
		sql.append(" ORDER BY categoria.cat_nome");
		
		try {
			pst = connection.prepareStatement(sql.toString());
			
			rs = pst.executeQuery();
			
			List<Entidade_Dominio> categorias = new ArrayList<Entidade_Dominio>();
			while(rs.next()) {
				categoria = new Categoria();
				
				categoria.setCodigo(rs.getInt("cat_id"));
				categoria.setNome(rs.getString("cat_nome"));
				categoria.setDescricao(rs.getString("cat_descricao"));
				categoria.setStatus(rs.getBoolean("cat_status"));

				categorias.add(categoria);
			}
			return categorias;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(ctrlTransaction == true) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
		return null;
	}
}
