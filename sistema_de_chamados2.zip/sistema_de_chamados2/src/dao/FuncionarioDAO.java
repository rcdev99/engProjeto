package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dominio.Funcionario;
import dominio.Entidade_Dominio;

public class FuncionarioDAO extends AbstractJdbcDAO {

	private static final String name_table = "funcionario";
	private static final String id_table = "fun_id";
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public FuncionarioDAO() {
		super(name_table, id_table);
	}
	
	public FuncionarioDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(Entidade_Dominio entidadeDominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Funcionario funcionario = (Funcionario) entidadeDominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("(fun_id, fun_id_regiao, fun_id_setor, fun_id_grupo, fun_id_responsavel, fun_status, fun_e_mail, fun_cargo, fun_dt_contracao ) ");
			sql.append("VALUES (?,?,?,?,?,?,?,?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setInt(1, funcionario.getId());
			pst.setInt(2, funcionario.getIdRegiao());
			pst.setInt(3, funcionario.getIdSetor());
			pst.setInt(4, funcionario.getIdGrupo());
			pst.setInt(5, funcionario.getIdResponsavel());
			pst.setBoolean(6, funcionario.isStatus());
			pst.setString(7, funcionario.getE_mail());
			pst.setString(8, funcionario.getCargo());
			pst.setDate(9, funcionario.getDt_contratacao());
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idFuncionario = 0;
			if(rs.next())
				idFuncionario = rs.getInt(1);
			funcionario.setId(idFuncionario);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Funcionario funcionario = (Funcionario)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("fun_e-mail, fun_cargo ");
			sql.append(" = (?,?) ");
			sql.append("WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, funcionario.getE_mail());
			pst.setString(2, funcionario.getCargo());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Funcionario funcionario = (Funcionario)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("DELETE FROM ");
			sql.append(name_table);
			sql.append(" WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, funcionario.getMatricula());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Funcionario funcionario = (Funcionario)entidadedominio;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM ");
		sql.append(name_table);
		
		sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
		
		if(funcionario.getMatricula() > 0) {
			sql.append(" AND funcionario.fun_id = ");
			sql.append(funcionario.getMatricula());
		}
		
		if(funcionario.getE_mail() != null) {
			sql.append(" AND funcionario.fun_e_mail ILIKE '%");
			sql.append(funcionario.getE_mail());
			sql.append("%'");
		}
		
		sql.append(" ORDER BY funcionario.fun_id");
		
		try {
			pst = connection.prepareStatement(sql.toString());
			
			rs = pst.executeQuery();
			
			List<Entidade_Dominio> funcionarios = new ArrayList<Entidade_Dominio>();
			while(rs.next()) {
				funcionario = new Funcionario();
				
				funcionario.setMatricula(rs.getInt("fun_id"));
				funcionario.setIdRegiao(rs.getInt("fun_id_regiao"));
				funcionario.setIdSetor(rs.getInt("fun_id_setor"));
				funcionario.setIdGrupo(rs.getInt("fun_id_grupo"));
				funcionario.setIdResponsavel(rs.getInt("fun_id_responsavel"));
				funcionario.setStatus(rs.getBoolean("fun_status"));
				funcionario.setE_mail(rs.getString("fun_e_mail"));
				funcionario.setCargo(rs.getString("fun_cargo"));
				funcionario.setDt_contratacao(rs.getDate("fun_dt_contratacao"));
				
				
				funcionarios.add(funcionario);
			}
			return funcionarios;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(ctrlTransaction == true) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
		return null;
	}

	
}
