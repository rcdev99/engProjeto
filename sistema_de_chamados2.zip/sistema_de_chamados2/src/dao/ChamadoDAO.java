package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import dominio.Chamado;
import dominio.Entidade_Dominio;


public class ChamadoDAO extends AbstractJdbcDAO{
		
		private static final String name_table = "chamado";
		private static final String id_table = "cdo_id";
		PreparedStatement pst = null;
		ResultSet rs = null;
		
		public ChamadoDAO() {
			super(name_table, id_table);
		}
		
		public ChamadoDAO(Connection cx) {
			super(cx,name_table, id_table);
		}
 
	@Override
	public void salvar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Chamado chamado = (Chamado)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("(cdo_id , cdo_id_categoria, cdo_id_subcategoria, cdo_id_grupo, cdo_id_responsavel, cdo_id_setor, cdo_id_regional, "
					+ "cdo_nome, cdo_status, cdo_descricao, cdo_situacao, cdo_dt_abertura, cdo_previsao_encerramento, cdo_dt_encerramento, cdo_id_conhecimento)");
			sql.append("VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setInt(1, chamado.getId());
			pst.setInt(2, chamado.getCategoriaId());
			pst.setInt(3, chamado.getSubcategoriaId());
			pst.setInt(4, chamado.getGrupoId());
			pst.setInt(5, chamado.getResponsavelId());
			pst.setInt(6, chamado.getSetorId());
			pst.setInt(7, chamado.getRegionalId());
			pst.setString(8, chamado.getNome());
			pst.setBoolean(9, chamado.getStatus2());
			pst.setString(10, chamado.getDescricao());
			pst.setString(11, chamado.getSituacao());
			pst.setDate(12, chamado.getDt_abertura());
			pst.setDate(13, chamado.getPrevisaoEncerramento());
			pst.setDate(14, chamado.getDt_encerramento());
			pst.setInt(15, chamado.getConhecimentoId());
			
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idChamado= 0;
			if(rs.next())
				idChamado= rs.getInt(1);
			chamado.setId(idChamado);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Chamado chamado = (Chamado)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("cdo_nome, cdo_situacao, cdo_descricao, cdo_dt_abertura, cdo_previsao_encerramento");
			sql.append(" = (?,?,?,?,?)");
			sql.append("WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, chamado.getNome());
			pst.setString(2, chamado.getSituacao());
			pst.setString(3, chamado.getDescricao());
			pst.setDate(4, chamado.getDt_abertura());
			pst.setDate(5, chamado.getPrevisaoEncerramento());
			pst.setInt(6, chamado.getCod());
			
			
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
