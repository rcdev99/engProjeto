package dao;

import java.sql.SQLException;
import java.util.List;

import dominio.Entidade_Dominio;;

public interface IDAO {

	public void salvar(Entidade_Dominio entidadedominio) throws SQLException;
	public void alterar(Entidade_Dominio entidadedominio)throws SQLException;
	public void excluir(Entidade_Dominio entidadedominio)throws SQLException;
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException;
	
}