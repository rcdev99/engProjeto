package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import dominio.Setor;
import dominio.Entidade_Dominio;
import dominio.Regional;

@SuppressWarnings("unused")
public class SetorDAO extends AbstractJdbcDAO {

	private static final String name_table = "setor";
	private static final String id_table = "str_id";
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public SetorDAO() {
		super(name_table, id_table);
	}
	
	public SetorDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Setor setor = (Setor)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("(str_nome) ");
			sql.append("VALUES (?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setString(2, setor.getSetor());
			
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idCliente = 0;
			if(rs.next())
				idCliente = rs.getInt(1);
			setor.setId(idCliente);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Setor setor = (Setor)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("str_nome");
			sql.append(" = (?) ");
			sql.append("WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, setor.getSetor());
			
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Setor setor = (Setor)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("DELETE FROM ");
			sql.append(name_table);
			sql.append(" WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, setor.getCod());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		Setor setor = (Setor)entidadedominio;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM ");
		sql.append(name_table);
		
		sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
		
		if(setor.getCod() > 0) {
			sql.append(" AND setor.str_id = ");
			sql.append(setor.getCod());
		}
		
		if(setor.getSetor() != null) {
			sql.append(" AND regional.reg_nome ILIKE '%");
			sql.append(setor.getSetor());
			sql.append("%'");
		}
		
		sql.append(" ORDER BY setor.str_nome");
		
		try {
			pst = connection.prepareStatement(sql.toString());
			
			rs = pst.executeQuery();
			
			List<Entidade_Dominio> setores = new ArrayList<Entidade_Dominio>();
			while(rs.next()) {
				setor = new Setor();
				
				setor.setCod(rs.getInt("str_id"));
				setor.setSetor(rs.getString("str_nome"));

				setores.add(setor);
			}
			return setores;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(ctrlTransaction == true) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
		return null;
	}
}
