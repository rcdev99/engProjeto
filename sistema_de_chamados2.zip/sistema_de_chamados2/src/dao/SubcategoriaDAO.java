package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dominio.Entidade_Dominio;
import dominio.Subcategoria;

public class SubcategoriaDAO extends AbstractJdbcDAO {

	private static final String name_table = "subcategoria";
	private static final String id_table = "sub_id";
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public SubcategoriaDAO() {
		super(name_table, id_table);
	}
	
	public SubcategoriaDAO(Connection cx) {
		super(cx,name_table, id_table);
	}
	
	@Override
	public void salvar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Subcategoria sub = (Subcategoria)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("(sub_id, sub_id_categoria, sub_prazoatendimento, sub_nome, sub_status, sub_descricao) ");
			sql.append("VALUES (?,?,?,?,?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setInt(1, sub.getId());
			pst.setInt(2, sub.getCategoriaId());
			pst.setDate(3, sub.getPrazoAtendimento());
			pst.setString(4, sub.getSubcategoria());
			pst.setBoolean(5, sub.getStatus());
			pst.setString(6, sub.getDescricao());
			
			
			
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idSub= 0;
			if(rs.next())
				idSub= rs.getInt(1);
			sub.setId(idSub);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Subcategoria sub = (Subcategoria)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("sub_id_categoria, sub_prazoatendimento, sub_nome, sub_descricao ");
			sql.append(" = (?, ?, ?, ?) ");
			sql.append("WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, sub.getCategoriaId());
			pst.setDate(2, sub.getPrazoAtendimento());
			pst.setString(3, sub.getSubcategoria());
			pst.setString(4, sub.getDescricao());
			pst.setInt(5, sub.getId());
			
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Subcategoria sub = (Subcategoria)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("DELETE FROM ");
			sql.append(name_table);
			sql.append(" WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, sub.getCod());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		Subcategoria sub= (Subcategoria)entidadedominio;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM ");
		sql.append(name_table);
		
		sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
		
		if(sub.getCod() > 0) {
			sql.append(" AND subcategoria.sub_id = ");
			sql.append(sub.getCod());
		}
		
		if(sub.getSubcategoria() != null) {
			sql.append(" AND subcategoria.sub_nome ILIKE '%");
			sql.append(sub.getSubcategoria());
			sql.append("%'");
		}
		
		sql.append(" ORDER BY subcategoria.sub_nome");
		
		try {
			pst = connection.prepareStatement(sql.toString());
			
			rs = pst.executeQuery();
			
			List<Entidade_Dominio> subcategorias = new ArrayList<Entidade_Dominio>();
			while(rs.next()) {
				sub = new Subcategoria();
				
				sub.setCod(rs.getInt("sub_id"));
				sub.setCategoriaId(rs.getInt("sub_id_categoria"));
				sub.setPrazoAtendimento(rs.getDate("sub_prazoatendimento"));
				sub.setSubcategoria(rs.getString("sub_nome"));
				sub.setStatus(rs.getBoolean("sub_status"));
				sub.setDescricao(rs.getString("sub_descricao"));
				

				subcategorias.add(sub);
			}
			return subcategorias;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(ctrlTransaction == true) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
		return null;
	}

}
