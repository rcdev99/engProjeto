package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dominio.Entidade_Dominio;
import dominio.Regional;

public class RegionalDAO extends AbstractJdbcDAO{

	private static final String name_table = "regional";
	private static final String id_table = "reg_id";
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public RegionalDAO() {
		super(name_table, id_table);
	}
	
	public RegionalDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Regional regional = (Regional)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("(reg_nome, reg_status) ");
			sql.append("VALUES (?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setString(1, regional.getRegiao());
			pst.setBoolean(2, regional.isStatus());
			
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idRegiao= 0;
			if(rs.next())
				idRegiao= rs.getInt(1);
			regional.setCod(idRegiao);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Regional regional = (Regional)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("UPDATE ");
			sql.append(name_table);
			sql.append(" SET ");
			sql.append("reg_nome");
			sql.append(" = (?) ");
			sql.append("WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setString(1, regional.getRegiao());
			pst.setInt(2, regional.getCod());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Regional regional = (Regional)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("DELETE FROM ");
			sql.append(name_table);
			sql.append(" WHERE ");
			sql.append(id_table);
			sql.append("=(?)");
			
			
			pst = connection.prepareStatement(sql.toString(), Statement.SUCCESS_NO_INFO );
			
			pst.setInt(1, regional.getCod());
			
			pst.executeUpdate();
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		Regional regional = (Regional)entidadedominio;
		
		StringBuilder sql = new StringBuilder();
		
		sql.append("SELECT * FROM ");
		sql.append(name_table);
		
		sql.append(" WHERE 1 = 1 ");		//Utilizado para diminuir o n�mero de IF's
		
		if(regional.getCod() > 0) {
			sql.append(" AND regional.reg_id = ");
			sql.append(regional.getCod());
		}
		
		if(regional.getRegiao() != null) {
			sql.append(" AND regional.reg_nome ILIKE '%");
			sql.append(regional.getRegiao());
			sql.append("%'");
		}
		
		sql.append(" ORDER BY regional.reg_nome");
		
		try {
			pst = connection.prepareStatement(sql.toString());
			
			rs = pst.executeQuery();
			
			List<Entidade_Dominio> regioes = new ArrayList<Entidade_Dominio>();
			while(rs.next()) {
				regional = new Regional();
				
				regional.setCod(rs.getInt("reg_id"));
				regional.setRegiao(rs.getString("reg_nome"));

				regioes.add(regional);
			}
			return regioes;
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(ctrlTransaction == true) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		
		return null;
	}
}
