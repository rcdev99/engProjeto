package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import dominio.Entidade_Dominio;
import dominio.Grupo;


public class GrupoDAO extends AbstractJdbcDAO {

	private static final String name_table = "grupo";
	private static final String id_table = "id_grupo";
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	public GrupoDAO() {
		super(name_table, id_table);
	}
	
	public GrupoDAO(Connection cx) {
		super(cx,name_table, id_table);
	}

	@Override
	public void salvar(Entidade_Dominio entidadedominio) throws SQLException {
		if(connection == null) {
			openConnection();
		}
		
		Grupo grupo = (Grupo)entidadedominio;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sql = new StringBuilder();
			
			
			sql.append("INSERT INTO ");
			sql.append(name_table);
			sql.append("(id_grupo, grupo) ");
			sql.append("VALUES (?,?);");
			
			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setInt(1, grupo.getId());
			pst.setString(2, grupo.getNome());
			
			pst.executeUpdate();

			rs = pst.getGeneratedKeys();
			int idGrupo= 0;
			if(rs.next())
				idGrupo= rs.getInt(1);
			grupo.setId(idGrupo);
			
			connection.commit();
			
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		
	}

	@Override
	public void alterar(Entidade_Dominio entidadedominio) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void excluir(Entidade_Dominio entidadedominio) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Entidade_Dominio> consultar(Entidade_Dominio entidadedominio) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
